﻿namespace Shared.DataTransferObjects;

public class AssignMateriasDto
{
    public IEnumerable<Guid> materiaIds { get; set; }
}
