﻿namespace Shared.DataTransferObjects;

public record DireccionAcudienteForCreationDto(string Calle,string ColoniaBarrio,string CiudadLocalidad, string CodigoPostal, string EstadoProvincia,string Pais);
